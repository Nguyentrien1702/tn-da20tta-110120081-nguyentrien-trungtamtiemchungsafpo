
</div>
<div class="container-menu"> 
        <footer>
            <h5>CÔNG TY TNHH AMV DỊCH VỤ Y TẾ </h5>
            <h5>PHÒNG TIÊM CHỦNG SAFPO 43 - TRÀ VINH</h5>
            <p>Chính sách bảo mật thông tin| Điều khoản sử dụng</p>
            <p>Địa chỉ: Số 79, đường Lý Tự Trọng, phường 4, thành phố Trà Vinh, tỉnh Trà Vinh</p>
            <p>Điện thoại: 0294 650 8508 </p>
        </footer>
    </div>
</div>
</body>
</html>